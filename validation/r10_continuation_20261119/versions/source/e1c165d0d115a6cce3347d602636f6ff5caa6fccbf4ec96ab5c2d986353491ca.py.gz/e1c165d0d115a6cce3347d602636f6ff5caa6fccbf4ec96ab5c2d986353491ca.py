import sys
sys.path.insert(0,'/home/ceihao/robot_project/optimization_v2/ws/src/task_platform/scripts')
"""Only task actuator request owner. Independently gates Nav2 against observed state."""
import argparse,json,time,signal,math
from pathlib import Path
import numpy as np
from recovery_mowing_r10 import gear_permitted,arm_direction
from obstruction_memory_r10 import ObstructionMemory
import rclpy
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rosgraph_msgs.msg import Clock

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--config',type=Path,required=True);ap.add_argument('--session',required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True);c=json.loads(a.config.read_text());v=c['vehicle'];rclpy.init();n=rclpy.create_node('r09_actuator_gate',parameter_overrides=[rclpy.parameter.Parameter('use_sim_time',value=True)]);st=dict(t=0.,stop=False,enc=None,odom=None,loc=None,safety=None,tool=None,worker=None,bt=None,cmd=None,cmd_wall=0.,clock_wall=time.monotonic());seq=0;contextseq=0;progress=0.;lastpose=None;last_gear=0
    cmdpub=n.create_publisher(String,'/s03/actuator/request',10);btpub=n.create_publisher(String,'/r06/context',10);statepub=n.create_publisher(String,'/r07/gate',10);log=(a.out/'gate.jsonl').open('w');obstruction=ObstructionMemory(c['obstruction_evidence']['clear_hold_s'])
    def clock(m):
        t=m.clock.sec+m.clock.nanosec*1e-9
        if t!=st['t']:st['clock_wall']=time.monotonic()
        if t<st['t']:st['stop']=True
        st['t']=t
    n.create_subscription(Clock,'/clock',clock,qos_profile_sensor_data)
    for topic,key in [('/s03/encoders','enc'),('/r07/localization','loc'),('/r07/safety','safety'),('/s10/action/state','tool'),('/r07/mission','worker'),('/r06/directive','bt')]:
        n.create_subscription(String,topic,lambda m,k=key:st.update({k:json.loads(m.data)}),20 if key=='enc' else 10)
    n.create_subscription(Odometry,'/s05/odometry',lambda m:st.update(odom=dict(t=m.header.stamp.sec+m.header.stamp.nanosec*1e-9,v=m.twist.twist.linear.x,w=m.twist.twist.angular.z)),30)
    n.create_subscription(Twist,'/r07/nav_cmd_vel',lambda m:st.update(cmd=m,cmd_wall=time.monotonic()),10)
    def fresh(x,age):return bool(x and -.03<=st['t']-x.get('t',-100)<age)
    def tick():
        nonlocal seq,contextseq,progress,lastpose,last_gear
        t=st['t'];loc=st['loc'] or {};s=st['safety'] or {};tool=st['tool'] or {};worker=st['worker'] or {};bt=st['bt'] or {};enc=st['enc'];now=time.monotonic()
        localized=fresh(loc,.15) and loc.get('valid',False);healthy=fresh(s,.45) and s.get('valid',False)
        odom=st['odom'] or {};stopped=fresh(odom,.15) and abs(odom.get('v',100))<v['safety']['stopped_v_mps'] and abs(odom.get('w',100))<v['safety']['stopped_w_rad_s']
        tool_stopped=fresh(tool,.15) and tool.get('stopped_confirmed',False) and not tool.get('active',True)
        workerfresh=fresh(worker,.2);nav_idle=workerfresh and worker.get('nav_idle',False)
        if workerfresh:last_gear=arm_direction(last_gear,worker.get('direction'),worker.get('phase'),stopped,tool_stopped)
        if localized:
            p=loc['odom']
            if lastpose is not None:progress+=min(.1,math.dist(p[:2],lastpose[:2])+.25*abs(math.atan2(math.sin(p[2]-lastpose[2]),math.cos(p[2]-lastpose[2]))))
            lastpose=p
        blocked=obstruction.update(t,healthy,s.get('max_speed',0)<=0) or bool(worker.get('nav_failed'))
        contextseq+=1;context=dict(stamp=t,sequence=contextseq,obligation_id=worker.get('execution_segment_id'),obligation_direction=worker.get('direction'),sensor_capture=(s.get('terrain_health')or{}).get('t',-1.),session=a.session,task_version=c['version'],vehicle_hash=v['config_hash'],rig_revision=c['rig']['revision'],localized=localized,sensors_healthy=healthy,stopped=stopped,tool_stopped=tool_stopped,nav_idle=nav_idle,remaining_s=max(0,c['task_budget_s']-t),next_min_s=3.,blocked=blocked,complete=worker.get('complete',False),commanded_motion=workerfresh and worker.get('phase')=='NAVIGATING',progress_m=progress,replans=worker.get('replans',0),deferrals=worker.get('deferrals',0),alternative=worker.get('alternative',False),detour_valid=False,worker_fresh=workerfresh,loc_age=t-loc.get('t',-100),sensor_age=t-s.get('t',-100),reference_valid=loc.get('valid',False))
        btpub.publish(String(data=json.dumps(context)))
        working_segment=workerfresh and worker.get('segment')=='COVERAGE' and worker.get('direction')==1 and not worker.get('work_complete',False)
        tool_ready=(fresh(tool,.15) and tool.get('active',False) and tool.get('working_confirmed',False)) if working_segment else tool_stopped
        reasons=[]
        for ok,reason in [(localized,'LOCALIZATION'),(healthy,'PERCEPTION'),(fresh(bt,.15),'BT_STALE'),(workerfresh,'TASK_STALE'),(now-st['clock_wall']<.2,'CLOCK'),(now-st['cmd_wall']<.2,'NAV_COMMAND_STALE'),(tool_ready,'TOOL_STATE_FOR_SEGMENT'),(not blocked,'OBSTRUCTED')]:
            if not ok:reasons.append(reason)
        allowed=not reasons and bt.get('action') in ['EXECUTE','FOLLOW','DETOUR'] and worker.get('phase')=='NAVIGATING'
        vv=ww=0.;mode='STOP'
        if allowed and st['cmd']:
            vv=st['cmd'].linear.x;ww=st['cmd'].angular.z
            if not math.isfinite(vv+ww) or vv*worker.get('direction',1)<-.001 or abs(vv)>c['speed_cap_mps']+.05 or abs(ww)>c['yaw_cap_rps']+.05:allowed=False;reasons.append('NAV_COMMAND_RANGE')
            else:
                requested_gear=1 if vv>.001 else -1 if vv<-.001 else 0
                recovery=worker.get('endpoint_recovery',False) and worker.get('segment')=='TURN_TOOL_OFF' and worker.get('direction')==0
                if worker.get('direction')==0 and not recovery:allowed=False;reasons.append('UNAUTHORIZED_BIDIRECTIONAL_COMMAND')
                if not gear_permitted(last_gear,requested_gear,stopped,tool_stopped):allowed=False;reasons.append('MEASURED_GEAR_STOP_REQUIRED')
                if allowed and requested_gear:last_gear=requested_gear
                cap=min(c['reverse_cap_mps'] if vv<0 else c['speed_cap_mps'],loc.get('max_speed',0),s['max_speed'],bt.get('speed_cap_mps',0));original_v=vv;vv=math.copysign(min(abs(vv),cap),vv);curvature=ww/original_v if abs(original_v)>.001 else 0.;curvature=max(-v['steering']['max_curvature'],min(v['steering']['max_curvature'],curvature));ww=vv*curvature;mode='DRIVE' if enc and enc['armed'] else 'ARM'
        if not allowed or mode!='DRIVE':vv=ww=0.
        if enc:
            seq+=1;cmdpub.publish(String(data=json.dumps(dict(session=a.session,revision=v['config_hash'],epoch=enc['epoch'],sequence=seq,stamp=t,mode=mode,v=vv,w=ww))))
        d=dict(t=t,allowed=allowed,mode=mode,v=vv,w=ww,reasons=reasons,stopped=stopped,tool_stopped=tool_stopped,nav_idle=nav_idle,progress_m=progress,armed_direction=last_gear,raw_nav_v=st['cmd'].linear.x if st['cmd'] else None,raw_nav_w=st['cmd'].angular.z if st['cmd'] else None);statepub.publish(String(data=json.dumps(d)));log.write(json.dumps(d)+'\n');log.flush()
    n.create_timer(.03,tick)
    def stop(s,f):st['stop']=True
    for s in [signal.SIGINT,signal.SIGTERM]:signal.signal(s,stop)
    (a.out/'ready').write_text('sole leased actuator request publisher')
    try:
        while not st['stop']:rclpy.spin_once(n,timeout_sec=.005)
    finally:
        st['worker']=None;tick();log.close();n.destroy_node();rclpy.try_shutdown()
if __name__=='__main__':main()
